# AIoT Live Water-Quality Dashboard

## Files
- `app.py`: Streamlit dashboard with MQTT subscriber and Isolation Forest scoring.
- `requirements.txt`: Python dependencies.
- `aiot_live_data.csv`: Add your saved baseline dataset here before running/deploying.

## Required baseline CSV columns
`temperature`, `ph`, `dissolved_oxygen`

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

Keep your Wokwi ESP32 simulation running and publishing to:
`aiot/waterquality/demo_48271`

This demo uses the public, unencrypted MQTT broker `test.mosquitto.org`; use synthetic data only.
The anomaly detector is trained on the small saved baseline CSV and is not validated for real-world water safety.
