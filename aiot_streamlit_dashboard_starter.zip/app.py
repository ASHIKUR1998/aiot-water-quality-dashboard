import json
import threading
from datetime import datetime, timezone
from collections import deque

import pandas as pd
import streamlit as st
import paho.mqtt.client as mqtt
from sklearn.ensemble import IsolationForest

# ---------------- Configuration ----------------
MQTT_BROKER = "test.mosquitto.org"
MQTT_PORT = 1883
MQTT_TOPIC = "aiot/waterquality/demo_48271"
FEATURES = ["temperature", "ph", "dissolved_oxygen"]
MAX_ROWS = 200

st.set_page_config(
    page_title="AIoT Water-Quality Monitor",
    page_icon="💧",
    layout="wide",
)

# Shared process state: persists between Streamlit reruns.
if "live_rows" not in st.session_state:
    st.session_state.live_rows = deque(maxlen=MAX_ROWS)
if "mqtt_started" not in st.session_state:
    st.session_state.mqtt_started = False
if "mqtt_client" not in st.session_state:
    st.session_state.mqtt_client = None
if "mqtt_error" not in st.session_state:
    st.session_state.mqtt_error = None

# Keep references in module-level globals so MQTT callbacks can access them.
# This is a simple single-user demo, not a multi-user production service.
if "_aiot_live_rows" not in globals():
    _aiot_live_rows = deque(maxlen=MAX_ROWS)
    _aiot_lock = threading.Lock()
    _aiot_client = None
    _aiot_connected = False
    _aiot_error = None

@st.cache_resource
def load_model():
    baseline_path = "aiot_live_data.csv"
    baseline = pd.read_csv(baseline_path)
    X = baseline[FEATURES].apply(pd.to_numeric, errors="coerce").dropna()
    if len(X) < 5:
        raise ValueError("Baseline CSV needs at least 5 valid sensor readings.")
    detector = IsolationForest(
        n_estimators=100,
        contamination=0.10,
        random_state=42
    )
    detector.fit(X)
    return detector, len(X)

def on_connect(client, userdata, flags, reason_code, properties=None):
    global _aiot_connected, _aiot_error
    if reason_code == 0:
        _aiot_connected = True
        _aiot_error = None
        client.subscribe(MQTT_TOPIC)
    else:
        _aiot_connected = False
        _aiot_error = f"MQTT connection failed: {reason_code}"

def on_disconnect(client, userdata, disconnect_flags, reason_code, properties=None):
    global _aiot_connected
    _aiot_connected = False

def on_message(client, userdata, msg):
    global _aiot_error
    try:
        payload = json.loads(msg.payload.decode("utf-8"))
        row = {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            "temperature": float(payload["temperature"]),
            "ph": float(payload["ph"]),
            "dissolved_oxygen": float(payload["dissolved_oxygen"]),
        }
        X = pd.DataFrame([[row[c] for c in FEATURES]], columns=FEATURES)
        row["anomaly_score"] = float(_aiot_model.decision_function(X)[0])
        row["status"] = (
            "Typical pattern"
            if int(_aiot_model.predict(X)[0]) == 1
            else "Potential anomaly"
        )
        with _aiot_lock:
            _aiot_live_rows.append(row)
    except Exception as exc:
        _aiot_error = f"Message processing error: {exc}"

try:
    _aiot_model, baseline_count = load_model()
except Exception as exc:
    st.error(f"Could not load baseline model: {exc}")
    st.info("Upload your aiot_live_data.csv baseline file into the same GitHub repository as app.py.")
    st.stop()

st.markdown("""
<style>
.block-container {padding-top: 1.4rem; padding-bottom: 2rem;}
div[data-testid="stMetric"] {background: #f4f8ff; padding: 14px; border-radius: 12px; border: 1px solid #dce8f8;}
</style>
""", unsafe_allow_html=True)

st.title("💧 AIoT Live Water-Quality Monitoring")
st.caption("ESP32 simulator  •  MQTT  •  Python  •  Isolation Forest")

left, right = st.columns([3, 1])
with left:
    st.write(f"**MQTT topic:** `{MQTT_TOPIC}`")
    st.write(f"**Model baseline:** {baseline_count} saved simulated readings")
with right:
    if st.button("Connect / reconnect MQTT", type="primary", use_container_width=True):
        try:
            if _aiot_client is not None:
                _aiot_client.disconnect()
                _aiot_client.loop_stop()
            client = mqtt.Client(
                callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
                client_id=f"aiot-dashboard-{datetime.now().strftime('%H%M%S%f')}"
            )
            client.on_connect = on_connect
            client.on_disconnect = on_disconnect
            client.on_message = on_message
            client.connect(MQTT_BROKER, MQTT_PORT, keepalive=45)
            client.loop_start()
            _aiot_client = client
            st.session_state.mqtt_started = True
            st.session_state.mqtt_error = None
        except Exception as exc:
            _aiot_error = f"Could not start MQTT: {exc}"

status_col, topic_col = st.columns([1, 3])
with status_col:
    if _aiot_connected:
        st.success("MQTT connected")
    else:
        st.warning("MQTT not connected yet")
with topic_col:
    st.caption("Keep your Wokwi ESP32 simulation running and publishing to the exact topic above.")

if _aiot_error:
    st.error(_aiot_error)

@st.fragment(run_every="3s")
def live_dashboard():
    with _aiot_lock:
        rows = list(_aiot_live_rows)
    data = pd.DataFrame(rows)

    if data.empty:
        st.info("Waiting for live readings. Click **Connect / reconnect MQTT**, then check that Wokwi is running.")
        return

    latest = data.iloc[-1]
    anomalies = int((data["status"] == "Potential anomaly").sum())

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Temperature", f"{latest['temperature']:.2f} °C")
    c2.metric("pH", f"{latest['ph']:.2f}")
    c3.metric("Dissolved oxygen", f"{latest['dissolved_oxygen']:.2f} mg/L")
    c4.metric("Potential anomalies", f"{anomalies} / {len(data)}")

    if latest["status"] == "Potential anomaly":
        st.error(f"⚠️ Latest reading flagged as a potential anomaly (score {latest['anomaly_score']:.5f}).")
    else:
        st.success(f"Latest reading: Typical pattern (score {latest['anomaly_score']:.5f}).")

    st.subheader("Sensor trends")
    chart_data = data.tail(50).copy()
    chart_data.index = range(len(chart_data))
    chart_cols = st.columns(3)
    for col, feature, title, y_label in [
        (chart_cols[0], "temperature", "Temperature", "°C"),
        (chart_cols[1], "ph", "pH", "pH"),
        (chart_cols[2], "dissolved_oxygen", "Dissolved oxygen", "mg/L"),
    ]:
        with col:
            st.markdown(f"**{title} ({y_label})**")
            st.line_chart(chart_data[feature], height=220)

    st.subheader("Live readings")
    shown = data.iloc[::-1].reset_index(drop=True)
    st.dataframe(shown, use_container_width=True, hide_index=True)

    csv = data.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Download live log (CSV)",
        data=csv,
        file_name="aiot_live_anomaly_results.csv",
        mime="text/csv"
    )
    st.caption("Educational demo using simulated sensor values. Anomaly flags are not water-safety diagnoses.")

live_dashboard()
